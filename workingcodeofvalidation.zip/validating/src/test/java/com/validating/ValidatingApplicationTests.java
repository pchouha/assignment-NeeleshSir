package com.validating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
