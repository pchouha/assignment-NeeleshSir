package com.validating.domain;

import java.io.File;
import java.io.FileWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;


public class FilteringItemProcessor implements ItemProcessor<Contacts, Contacts> {
	/*@Override
	public Contacts process(Contacts item) throws Exception {

		if(item.getPhone().length()==10) {
			return null;
		}
		else {
			return item;
		}
	}
}*/
	
	 int count=0;
     private static final Logger LOGGER = LoggerFactory.getLogger(FilteringItemProcessor.class);
    @Override
    public Contacts process(Contacts p) throws Exception {
        count+=1;
        if(check(p)){
        return p;
    }
        return null;
    }

 

    private boolean check(Contacts p) {
        if((p.getPhone().length()==10) && checkFirstName(p) && checkLastName(p) && checkEmail(p) && checkPhone(p))
        {
        return true;
        }
        else{
            
            if(!(p.getPhone().length()==10)){
                String s ="Phone number must be 10 digits "+ p.getPhone();
                writ(s);
                LOGGER.error("Phone number must be 10 digits");
            }
        return false;
    }
    

 

}

 

    private  boolean checkLastName(Contacts p) {
        if(!p.getLastName().isEmpty()){
            return true;
        }
        else{
            String s="Last Name is Empty";
            writ(s);
            LOGGER.error("Last Name is Empty");
            return false;
            
        }
    }
    private boolean checkPhone(Contacts p) {        try{
            Long  l = Long.parseLong(p.getPhone());    
        }
        catch(NumberFormatException nfe){
            String s="Number must be Integer";
            writ(s);
            LOGGER.error("Number must be Integer");
            return false;
        }
        return true;
        
    }
    private boolean checkEmail(Contacts p) {
        if(!p.getEmail().isEmpty()){
        return true;
    }
    else{
        LOGGER.error("Last Email is Empty");
        String s="Last Email is Empty";
        writ(s);
        return false;
    }
}
    private boolean checkFirstName(Contacts p) {
        if(!p.getFirstName().isEmpty()){
            return true;
        }
        else{
            LOGGER.error("Last First Name is Empty");
            String s="Last First Name is Empty";
            writ(s);
            return false;
        }
    }
    
    private void writ(String s) {
        try{
//        File file = new File("Error.csv");
        	//File file = File.createTempFile("error_", ".csv"); new File("C:/Users/Vishvesh Savant/Desktop/Mirriad/"));
//        	File filePath = File.createTempFile("out_", ".csv", new File("C:/Users/Vishvesh Savant/Desktop/Mirriad/"));
        	File file = File.createTempFile("error_", ".txt", new File("C:/Users/prath/Documents/"));

        if(!file.exists())
        {file.createNewFile();
        }
        
        FileWriter fw = new FileWriter(file,true);
        
        fw.append("Contacts.csv"+","+count+","+s);
        fw.append('\n');
        fw.flush();
         
        fw.close();
        }
        catch(Exception e){
            System.out.println(e.toString());
        }

 

        
    }
}




