package com.validating.domain;

import java.io.File;
import java.io.FileWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

public class FilteringAddressProcessor implements ItemProcessor<Address, Address>{

	int count=0;
    private static final Logger LOGGER = LoggerFactory.getLogger(FilteringItemProcessor.class);
   @Override
   public Address process(Address p) throws Exception {
       count+=1;
       if(check(p)){
       return p;
   }
       return null;
   }
   
   private boolean check(Address p)
   {
	   if(!p.getAddressLine1().isEmpty() && checkcity(p) && checkcity2(p) && checkstatecode(p) && checkstatecode2(p) && checkAddressLine12(p))
	   {
		   return true;
	   }
	   else
	   {
		   String s = "AddressLine is not mentioned";
		   writ(s);
           LOGGER.error("AddressLine is not mentioned");
           
           return false;
	   }
   }
   
   private  boolean checkcity(Address p) {
       if(!p.getCity().isEmpty()){
           return true;
       }
       else{
           String s="City is not mentioned";
           writ(s);
           LOGGER.error("City is not mentioned");
           return false;
           
       }
   }
   
   private  boolean checkstatecode(Address p) {
       if(!p.getStateCode().isEmpty()){
           return true;
       }
       else{
           String s="StateCode is not mentioned";
           writ(s);
           LOGGER.error("StateCode is not mentioned");
           return false;
           
       }
   }
   
   private  boolean checkAddressLine12(Address p) {
       if(!p.getAddressLine12().isEmpty()){
           return true;
       }
       else{
           String s="AddressLine is not mentioned";
           writ(s);
           LOGGER.error("AddressLine is not mentioned");
           return false;
           
       }
   }
   
   private  boolean checkcity2(Address p) {
       if(!p.getCity2().isEmpty()){
           return true;
       }
       else{
           String s="City is not mentioned";
           writ(s);
           LOGGER.error("City is not mentioned");
           return false;
           
       }
   }
   
   private  boolean checkstatecode2(Address p) {
       if(!p.getStateCode2().isEmpty()){
           return true;
       }
       else{
           String s="StateCode is not mentioned";
           writ(s);
           LOGGER.error("StateCode is not mentioned");
           return false;
           
       }
   }
   
   
   private void writ(String s) {
	   
	   try{
		   File file = File.createTempFile("error_", ".txt", new File("C:/Users/prath/Documents/"));

	        if(!file.exists())
	        {file.createNewFile();
	        }
	        
	        FileWriter fw = new FileWriter(file,true);
	        
	        fw.append("Address.csv"+","+count+","+s);
	        fw.append('\n');
	        fw.flush();
	         
	        fw.close();
	        }
	        catch(Exception e){
	            System.out.println(e.toString());
	        }

	 

	        
	    }
	   
		   
	   
   

}
