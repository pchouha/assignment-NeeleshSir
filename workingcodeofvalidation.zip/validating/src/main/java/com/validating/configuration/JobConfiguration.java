package com.validating.configuration;

import javax.sql.DataSource;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
//import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
//import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
//import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.validating.domain.Address;
import com.validating.domain.AddressRowMapper;
import com.validating.domain.Contacts;


import com.validating.domain.FilteringAddressProcessor;
import com.validating.domain.FilteringItemProcessor;

//import io.spring.batch.domain.FilteringItemProcessor;

//import com.validating.domain.Contacts;
//import com.validating.*;
@Configuration
@EnableBatchProcessing
public class JobConfiguration {
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public DataSource dataSource;

	@Bean
	public FlatFileItemReader<Contacts> contactsItemReader() {
		FlatFileItemReader<Contacts> reader = new FlatFileItemReader<>();

		reader.setLinesToSkip(1);
		reader.setResource(new ClassPathResource("/data/Contacts.csv"));

		DefaultLineMapper<Contacts> contactsLineMapper = new DefaultLineMapper<>();

		DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
		tokenizer.setNames(new String[] { "lastName", "firstName", "phone", "email", "title", "designation" });

		contactsLineMapper.setLineTokenizer(tokenizer);
		contactsLineMapper.setFieldSetMapper(new BeanWrapperFieldSetMapper<Contacts>() {{
			setTargetType(Contacts.class);}}
		);
		contactsLineMapper.afterPropertiesSet();

		reader.setLineMapper(contactsLineMapper);

		return reader;
	}

	


	@Bean
	public JdbcBatchItemWriter<Contacts> contactsItemWriter() {
		JdbcBatchItemWriter<Contacts> itemWriter = new JdbcBatchItemWriter<>();

		itemWriter.setDataSource(this.dataSource);
		itemWriter
				.setSql("INSERT INTO CONTACTS VALUES (:lastName, :firstName, :phone, :email, :title, :designation)");
		itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Contacts>());
		itemWriter.afterPropertiesSet();

		return itemWriter;
	}

	/*@Bean
	public JdbcBatchItemWriter<Address> addressItemWriter() {
		JdbcBatchItemWriter<Address> itemWriter1 = new JdbcBatchItemWriter<>();

		itemWriter1.setDataSource(this.dataSource);
		itemWriter1.setSql(
				"INSERT INTO ADDRESS VALUES (:contactPhone, :addressType, :addressLine1, :addressLine2, :city, :statecode,:zipcode,:zipplus4,:addressType2,:addressLine12,:addressLine22,:city2,:statecode2,:zipcode2,:zipplus42)");
		itemWriter1.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Address>());
		itemWriter1.afterPropertiesSet();

		return itemWriter1;
	}*/

	@Bean
	public FilteringItemProcessor itemProcessor() {
		return new FilteringItemProcessor();
	}

	//@Bean
	//public FilteringAddressProcessor addressProcessor() {
		//return new FilteringAddressProcessor();
	//}

	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<Contacts, Contacts> chunk(1)
				
				.reader(contactsItemReader())
				.processor(itemProcessor()).writer(contactsItemWriter())
				.allowStartIfComplete(true)
				.build();
	}

	//@Bean
	//public Step step2() {
		//return stepBuilderFactory.get("step2").<Address, Address> chunk(1).reader(addressItemReader())
			//	.processor(addressProcessor()).writer(addressItemWriter()).build();
//	}

	@Bean
	public Job job() {
		return jobBuilderFactory.get("job")
				.start(step1())
				
				//.next(step2())
				.build();
	}
}
